"use client"

import type React from "react"
import { createContext, useContext, useState } from "react"
import type { Project, Task, Resource, Document, Announcement, DailyReport, WorkLog } from "./types"
import {
  mockProjects,
  mockTasks,
  mockResources,
  mockDocuments,
  mockAnnouncements,
  mockDailyReports,
  mockWorkLogs,
} from "./mock-data"

interface AppContextType {
  projects: Project[]
  tasks: Task[]
  resources: Resource[]
  documents: Document[]
  announcements: Announcement[]
  dailyReports: DailyReport[]
  workLogs: WorkLog[]
  addProject: (project: Project) => void
  updateProject: (project: Project) => void
  deleteProject: (id: string) => void
  addTask: (task: Task) => void
  updateTask: (task: Task) => void
  deleteTask: (id: string) => void
  addResource: (resource: Resource) => void
  updateResource: (resource: Resource) => void
  addDocument: (document: Document) => void
  deleteDocument: (id: string) => void
  addAnnouncement: (announcement: Announcement) => void
  addDailyReport: (report: DailyReport) => void
  addWorkLog: (log: WorkLog) => void
  getProjectTasks: (projectId: string) => Task[]
  getProjectDocuments: (projectId: string) => Document[]
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [projects, setProjects] = useState<Project[]>(mockProjects)
  const [tasks, setTasks] = useState<Task[]>(mockTasks)
  const [resources, setResources] = useState<Resource[]>(mockResources)
  const [documents, setDocuments] = useState<Document[]>(mockDocuments)
  const [announcements, setAnnouncements] = useState<Announcement[]>(mockAnnouncements)
  const [dailyReports, setDailyReports] = useState<DailyReport[]>(mockDailyReports)
  const [workLogs, setWorkLogs] = useState<WorkLog[]>(mockWorkLogs)

  const addProject = (project: Project) => {
    setProjects([...projects, project])
  }

  const updateProject = (updatedProject: Project) => {
    setProjects(projects.map((p) => (p.id === updatedProject.id ? updatedProject : p)))
  }

  const deleteProject = (id: string) => {
    setProjects(projects.filter((p) => p.id !== id))
  }

  const addTask = (task: Task) => {
    setTasks([...tasks, task])
  }

  const updateTask = (updatedTask: Task) => {
    setTasks(tasks.map((t) => (t.id === updatedTask.id ? updatedTask : t)))
  }

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((t) => t.id !== id))
  }

  const addResource = (resource: Resource) => {
    setResources([...resources, resource])
  }

  const updateResource = (updatedResource: Resource) => {
    setResources(resources.map((r) => (r.id === updatedResource.id ? updatedResource : r)))
  }

  const addDocument = (document: Document) => {
    setDocuments([...documents, document])
  }

  const deleteDocument = (id: string) => {
    setDocuments(documents.filter((d) => d.id !== id))
  }

  const addAnnouncement = (announcement: Announcement) => {
    setAnnouncements([...announcements, announcement])
  }

  const addDailyReport = (report: DailyReport) => {
    setDailyReports([...dailyReports, report])
  }

  const addWorkLog = (log: WorkLog) => {
    setWorkLogs([...workLogs, log])
  }

  const getProjectTasks = (projectId: string) => {
    return tasks.filter((t) => t.projectId === projectId)
  }

  const getProjectDocuments = (projectId: string) => {
    return documents.filter((d) => d.projectId === projectId)
  }

  return (
    <AppContext.Provider
      value={{
        projects,
        tasks,
        resources,
        documents,
        announcements,
        dailyReports,
        workLogs,
        addProject,
        updateProject,
        deleteProject,
        addTask,
        updateTask,
        deleteTask,
        addResource,
        updateResource,
        addDocument,
        deleteDocument,
        addAnnouncement,
        addDailyReport,
        addWorkLog,
        getProjectTasks,
        getProjectDocuments,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useApp must be used within AppProvider")
  }
  return context
}
