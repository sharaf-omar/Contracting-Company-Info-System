export interface Project {
  id: string
  name: string
  client: string
  location: string
  startDate: string
  endDate: string
  budget: number
  status: "Draft" | "Active" | "Completed" | "On Hold"
  progress: number
  objectives: string
  milestones: string[]
}

export interface Task {
  id: string
  projectId: string
  title: string
  description: string
  assignee: string
  dueDate: string
  status: "pending" | "in progress" | "completed"
  priority: "low" | "medium" | "high"
  dependencies: string[]
}

export interface Resource {
  id: string
  name: string
  type: "material" | "equipment" | "labor"
  quantity: number
  unit: string
  allocated: number
  cost: number
}

export interface Document {
  id: string
  projectId: string
  name: string
  type: "blueprint" | "contract" | "permit" | "specification" | "report"
  uploadDate: string
  size: string
  folder: string
  uploadedBy: string
}

export interface Announcement {
  id: string
  title: string
  message: string
  timestamp: string
  author: string
  priority: "normal" | "high" | "critical"
}

export interface DailyReport {
  id: string
  projectId: string
  taskId: string
  date: string
  activities: string
  issues: string
  completionPercentage: number
  photos: string[]
  submittedBy: string
}

export interface WorkLog {
  id: string
  taskId: string
  date: string
  hours: number
  notes: string
  submittedBy: string
}
