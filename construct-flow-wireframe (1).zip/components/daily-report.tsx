"use client"

import type React from "react"

import { useApp } from "@/lib/app-context"
import { useState } from "react"
import { Calendar, MapPin, AlertCircle } from "lucide-react"

export function DailyReport() {
  const { projects, addDailyReport } = useApp()
  const [reportForm, setReportForm] = useState({
    date: "",
    projectId: projects[0]?.id || "",
    taskId: "",
    activities: "",
    issues: "",
    completionPercentage: 50,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newReport = {
      id: `dr-${Date.now()}`,
      projectId: reportForm.projectId,
      taskId: reportForm.taskId,
      date: reportForm.date,
      activities: reportForm.activities,
      issues: reportForm.issues,
      completionPercentage: reportForm.completionPercentage,
      photos: [],
      submittedBy: "Current User",
    }

    addDailyReport(newReport)
    setReportForm({
      date: "",
      projectId: projects[0]?.id || "",
      taskId: "",
      activities: "",
      issues: "",
      completionPercentage: 50,
    })
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Daily Progress Report</h1>
          <p className="text-muted-foreground mt-2">Document daily site activities and progress</p>
        </div>

        <div className="bg-card p-8 rounded-lg border border-border">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                  <Calendar size={16} /> Report Date
                </label>
                <input
                  type="date"
                  value={reportForm.date}
                  onChange={(e) => setReportForm({ ...reportForm, date: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                  <MapPin size={16} /> Project
                </label>
                <select
                  value={reportForm.projectId}
                  onChange={(e) => setReportForm({ ...reportForm, projectId: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Activities Completed</label>
              <textarea
                placeholder="Summarize the day's activities and progress..."
                rows={3}
                value={reportForm.activities}
                onChange={(e) => setReportForm({ ...reportForm, activities: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Completion Percentage</label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={reportForm.completionPercentage}
                  onChange={(e) => setReportForm({ ...reportForm, completionPercentage: Number(e.target.value) })}
                  className="flex-1"
                />
                <span className="text-2xl font-bold text-primary w-12 text-right">
                  {reportForm.completionPercentage}%
                </span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                <AlertCircle size={16} className="text-amber-500" /> Issues & Concerns
              </label>
              <textarea
                placeholder="Document any issues, delays, or concerns..."
                rows={3}
                value={reportForm.issues}
                onChange={(e) => setReportForm({ ...reportForm, issues: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
              />
            </div>

            <div className="flex gap-4 pt-4 border-t border-slate-200">
              <button
                type="submit"
                className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium"
              >
                Submit Report
              </button>
              <button
                type="button"
                className="px-6 py-2 border border-slate-300 rounded-lg text-foreground hover:bg-slate-50 transition-colors font-medium"
              >
                Save Draft
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
