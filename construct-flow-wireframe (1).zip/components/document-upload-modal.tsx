"use client"

import type React from "react"

import { useState } from "react"
import { useApp } from "@/lib/app-context"

interface DocumentUploadModalProps {
  onClose: () => void
}

export function DocumentUploadModal({ onClose }: DocumentUploadModalProps) {
  const { addDocument, projects } = useApp()
  const [formData, setFormData] = useState({
    projectId: projects[0]?.id || "",
    name: "",
    type: "blueprint" as const,
    folder: "blueprints",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newDocument = {
      id: `doc-${Date.now()}`,
      projectId: formData.projectId,
      name: formData.name,
      type: formData.type,
      uploadDate: new Date().toISOString().split("T")[0],
      size: "2.5 MB",
      folder: formData.folder,
      uploadedBy: "Current User",
    }

    addDocument(newDocument)
    onClose()
  }

  return (
    <div className="p-6 max-w-2xl">
      <h2 className="text-2xl font-bold mb-6 text-foreground">Upload Document</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Project</label>
          <select
            name="projectId"
            value={formData.projectId}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Document Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            placeholder="e.g., Building Blueprints v2"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Document Type</label>
            <select
              name="type"
              value={formData.type}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="blueprint">Blueprint</option>
              <option value="contract">Contract</option>
              <option value="permit">Permit</option>
              <option value="specification">Specification</option>
              <option value="report">Report</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Folder</label>
            <select
              name="folder"
              value={formData.folder}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="blueprints">Blueprints</option>
              <option value="permits">Permits</option>
              <option value="contracts">Contracts</option>
              <option value="reports">Reports</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1">File Upload</label>
          <input type="file" className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
        </div>

        <div className="flex gap-3 pt-4">
          <button
            type="submit"
            className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 font-medium"
          >
            Upload Document
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-slate-100 text-foreground rounded-lg hover:bg-slate-200 font-medium"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  )
}
