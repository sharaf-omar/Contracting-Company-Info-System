"use client"

import { useApp } from "@/lib/app-context"

export function TaskOverview() {
  const { tasks, projects, getProjectTasks } = useApp()

  const getProjectName = (projectId: string) => {
    return projects.find((p) => p.id === projectId)?.name || "Unknown"
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in progress":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "completed":
        return "bg-green-100 text-green-800"
      default:
        return "bg-slate-100 text-slate-800"
    }
  }

  const criticalTasks = tasks
    .filter(
      (t) =>
        t.status === "in progress" ||
        (t.status === "pending" && new Date(t.dueDate) < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)),
    )
    .slice(0, 4)

  return (
    <div className="bg-card p-6 rounded-lg border border-border">
      <h3 className="text-lg font-bold text-foreground mb-6">Critical Tasks</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-4 font-semibold text-muted-foreground text-xs uppercase">Task</th>
              <th className="text-left py-3 px-4 font-semibold text-muted-foreground text-xs uppercase">Project</th>
              <th className="text-left py-3 px-4 font-semibold text-muted-foreground text-xs uppercase">Assignee</th>
              <th className="text-left py-3 px-4 font-semibold text-muted-foreground text-xs uppercase">Due Date</th>
              <th className="text-left py-3 px-4 font-semibold text-muted-foreground text-xs uppercase">Status</th>
            </tr>
          </thead>
          <tbody>
            {criticalTasks.map((task) => (
              <tr key={task.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                <td className="py-3 px-4 font-medium text-foreground">{task.title}</td>
                <td className="py-3 px-4 text-muted-foreground text-sm">{getProjectName(task.projectId)}</td>
                <td className="py-3 px-4 text-muted-foreground text-sm">{task.assignee}</td>
                <td className="py-3 px-4 text-muted-foreground text-xs">{task.dueDate}</td>
                <td className="py-3 px-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(task.status)}`}>
                    {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
